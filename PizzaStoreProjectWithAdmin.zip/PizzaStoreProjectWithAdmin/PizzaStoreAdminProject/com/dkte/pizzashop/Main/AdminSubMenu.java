package com.dkte.pizzashop.Main;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.dkte.pizzashop.dao.AdminDao;
import com.dkte.pizzashop.entities.Customer;
import com.dkte.pizzashop.entities.Orders;
import com.dkte.pizzashop.entities.Pizza;

public class AdminSubMenu {

	public static int adminMenu(Scanner sc) {
		System.out.println("********************************************");
		System.out.println("0. Back To Main Menu");
		System.out.println("1. Update the Price of Existing Pizzas ");
		System.out.println("2. Add New Pizza ");
		System.out.println("3. Delete the Pizza");
		System.out.println("4. Display all Customers ");
		System.out.println("5. Display all Orders ");
		System.out.println("6. Display Total Profit ");

		System.out.print("Enter Your Choice - ");
		return sc.nextInt();
	}

	public static void deletePizza(Scanner sc) throws SQLException, Exception {
		try (AdminDao adm = new AdminDao()) {
			int mid;
			System.out.print("Please Enter the mid of pizza you want to delete : ");
			mid = sc.nextInt();
			adm.delPizza(mid);
		}
	}

	public static void updatePrices(Scanner sc) throws SQLException, Exception {
		try (AdminDao adm = new AdminDao()) {
			int mid;
			double price;
			System.out.println("********************************");
			System.out.println("Entered to the Update Portal ");
			System.out.print("Enter the mid your want to update : ");
			mid = sc.nextInt();

			System.out.print("Enter the new Price you want to Set : ");
			price = sc.nextDouble();

			adm.updatePrice(mid, price);
			System.out.println("The value is Updated");

		}
	}

	public static void showCustomers() throws SQLException, Exception {
		try (AdminDao adm = new AdminDao()) {
			List<Customer> lists = new ArrayList<Customer>();
			lists = adm.showAllCustomers();

			lists.forEach(e -> System.out.println(e));

		}
	}

	public static void addPizza(Scanner sc) throws SQLException, Exception {
		System.out.println("********************************");
		System.out.println("Entered to the add pizza Portal ");
		try (AdminDao adm = new AdminDao()) {
			String name;
			System.out.println("Enter the name of the Pizza : ");
			name = sc.nextLine();
			double price;
			System.out.println("Enter the price of the Pizza : ");
			price = sc.nextDouble();
			String desc;
			System.out.println("Enter the Description of the pizza : ");
			desc = sc.nextLine();

			Pizza p = new Pizza(name, desc, price);

			adm.addPizza(p);
		}
	}

	public static List<Orders> OrdersAll() throws SQLException, Exception {
		System.out.println("********************************");
		try (AdminDao adm = new AdminDao()) {
			List<Orders> orderList = new ArrayList<Orders>();
			orderList = adm.allOrders();
			return orderList;
		}

	}

	public static void displayOrders() throws SQLException, Exception {
		List<Orders> orders = new ArrayList<Orders>();
		orders = OrdersAll();
		orders.forEach(e -> System.out.println(e));
	}

	public static void calculateProfit() throws SQLException, Exception {
		List<Double> prices = new ArrayList<Double>();
		try (AdminDao adm = new AdminDao()) {
			prices = adm.calProfit();
			double totalProfit = 0;
			for (Double d1 : prices) {
				totalProfit = totalProfit + d1;
			}
			System.out.println("Total Profit is : " + totalProfit + " Rs.");
		}
	}

	public static void adminSubMenu(Scanner sc) throws SQLException, Exception {
		int choice;
		System.out.println("Admin is Verified ");
		while ((choice = adminMenu(sc)) != 0) {
			switch (choice) {
			case 1:
				updatePrices(sc);
				break;

			case 2:
				addPizza(sc);
				break;

			case 3:
				deletePizza(sc);
				break;

			case 4:
				showCustomers();
				break;

			case 5:
				displayOrders();
				break;

			case 6:
				calculateProfit();
				break;
			}
		}
	}

}
