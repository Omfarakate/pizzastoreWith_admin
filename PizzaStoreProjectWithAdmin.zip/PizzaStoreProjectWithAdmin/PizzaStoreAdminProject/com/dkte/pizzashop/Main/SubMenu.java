package com.dkte.pizzashop.Main;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.dkte.pizzashop.dao.OrdersDao;
import com.dkte.pizzashop.dao.PizzaDao;
import com.dkte.pizzashop.entities.Customer;
import com.dkte.pizzashop.entities.Pizza;

public class SubMenu {

	public static int smenu(Scanner sc) {
		System.out.println("********************************************");
		System.out.println("Logged In Successfully");
		System.out.println("0. Logout");
		System.out.println("1. Pizza Menu ");
		System.out.println("2. Order a Pizza");
		System.out.println("3. Order History");
		System.out.print("Enter Your Choice - ");
		return sc.nextInt();
	}

	private static void displayMenu() throws SQLException, Exception {
		try (PizzaDao pizzadao = new PizzaDao()) {
			List<Pizza> pizzalist = new ArrayList<Pizza>();
			pizzalist = pizzadao.getPizza();
			pizzalist.forEach(e -> System.out.println(e));
		}
	}

	private static void displayOrderHistory(Customer customer) throws SQLException, Exception {
		try (OrdersDao ordersdao = new OrdersDao()) {
			List<Pizza> orderlist = new ArrayList<Pizza>();
			orderlist = ordersdao.OrderHistory(customer);
			if (orderlist != null)
				orderlist.forEach(e -> System.out.println(e));
			else
				System.out.println("No any orders from you");
		}
	}

	private static void PizzaOrder(Customer customer) throws SQLException, Exception {
		Scanner sc = new Scanner(System.in);
		try (OrdersDao ordersdao = new OrdersDao()) {
			System.out.print("Enter the Pizza id you want to buy : ");
			int id = sc.nextInt();
			ordersdao.insertOrder(customer, id);
		}

	}

	public static void subMenu(Scanner sc, Customer customer) throws SQLException, Exception {
		int choice;
		while ((choice = smenu(sc)) != 0) {
			switch (choice) {
			case 1:
				System.out.println("Pizza Menu is here");
				displayMenu();
				break;

			case 2:
				System.out.println("Order a Pizza");
				PizzaOrder(customer);
				System.out.println("You Ordered a Pizza");
				break;

			case 3:
				System.out.println("Order History");
				displayOrderHistory(customer);
				break;

			default:
				System.out.println("You entered the wrong choice :(");
				break;
			}

		}
		System.out.println("Logged Out Successfully ");
	}

	public static int menu(Scanner sc) {
		System.out.println("***************************");
		System.out.println("0. Logout");
		System.out.println("1. Pizza Menu ");
		System.out.println("2. Order a Pizza ");
		System.out.println("3. Order History ");
		return sc.nextInt();
	}

}
