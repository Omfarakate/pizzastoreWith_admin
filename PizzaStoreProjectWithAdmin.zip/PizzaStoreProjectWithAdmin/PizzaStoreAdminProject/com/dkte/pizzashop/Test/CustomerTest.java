package com.dkte.pizzashop.Test;

import java.sql.SQLException;
import java.util.Scanner;

import com.dkte.pizzashop.dao.CustomerDao;
import com.dkte.pizzashop.entities.Customer;

public class CustomerTest {

	public static void main(String[] args) throws SQLException {
		Scanner sc = new Scanner(System.in);
		Customer customer = new Customer();
		customer.acceptCustomer(sc);
		try (CustomerDao custDao = new CustomerDao()) {
			custDao.insertCustomer(customer);
		}
	}

}
