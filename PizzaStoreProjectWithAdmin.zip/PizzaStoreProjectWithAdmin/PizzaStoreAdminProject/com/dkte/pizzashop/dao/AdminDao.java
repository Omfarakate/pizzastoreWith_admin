package com.dkte.pizzashop.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.dkte.pizzashop.entities.Customer;
import com.dkte.pizzashop.entities.Orders;
import com.dkte.pizzashop.entities.Pizza;
import com.dkte.pizzashop.util.DBUtil;

public class AdminDao implements AutoCloseable {

	private Connection connection;

	public AdminDao() throws SQLException {
		connection = DBUtil.getConnection();
	}

	public void updatePrice(int mid, Double newPrice) throws SQLException {
		String sql = "Update menu SET price = ? Where mid =?";
		try (PreparedStatement updatePr = connection.prepareCall(sql)) {
			updatePr.setDouble(1, newPrice);
			updatePr.setInt(2, mid);
			updatePr.executeUpdate();
		}
	}

	public void addPizza(Pizza p) throws SQLException {

		String sql = "insert into menu(name,description,price)values(?,?,?)";
		try (PreparedStatement insertPizza = connection.prepareCall(sql)) {
			insertPizza.setString(1, p.getName());
			insertPizza.setString(2, p.getDescription());
			insertPizza.setDouble(3, p.getPrice());
			insertPizza.executeUpdate();
			System.out.println("New pizza - " + p.getName() + "is added ");
		}
	}

	public void delPizza(int mid) throws SQLException {
		String sql = "delete from menu where mid=?";
		try (PreparedStatement deletePizza = connection.prepareCall(sql)) {
			deletePizza.setInt(1, mid);
			deletePizza.executeUpdate();
		}
	}

	public List<Customer> showAllCustomers() throws SQLException {
		List<Customer> customerList = new ArrayList<Customer>();
		String sql = "select * from customer ";
		try (PreparedStatement showCust = connection.prepareCall(sql)) {
			ResultSet rs = showCust.executeQuery();

			while (rs.next()) {
				Customer cust = new Customer();
				cust.setCid(rs.getInt(1));
				cust.setName(rs.getString(2));
				cust.setEmail(rs.getString(3));
				cust.setPassword(rs.getString(4));
				cust.setMobile(rs.getString(5));
				customerList.add(cust);
			}

		}
		return customerList;
	}

	public List<Orders> allOrders() throws SQLException {
		List<Orders> orderList = new ArrayList<Orders>();
		String sql = "select * from orders";
		try (PreparedStatement orders = connection.prepareCall(sql)) {
			ResultSet rs = orders.executeQuery();
			if (rs != null) {
				while (rs.next()) {
					Orders or = new Orders();
					or.setOid(rs.getInt(1));
					or.setCid(rs.getInt(2));
					or.setMid(rs.getInt(3));
					orderList.add(or);
				}
			} else {
				System.out.println("No orders yet ");
			}
		}
		return orderList;

	}

	public List<Double> calProfit() throws SQLException {
		List<Double> profit = new ArrayList<Double>();
		String sql = "select price from menu join orders where orders.mid=menu.mid";
		try (PreparedStatement profits = connection.prepareCall(sql)) {
			ResultSet rs = profits.executeQuery();

			if (rs != null) {
				while (rs.next()) {
					double d;
					d = rs.getDouble(4);
					profit.add(d);
				}
			} else {
				System.out.println("No orders yet ");
			}
		}
		return profit;
	}

	@Override
	public void close() throws Exception {
		if (connection != null)
			connection.close();
	}

}
