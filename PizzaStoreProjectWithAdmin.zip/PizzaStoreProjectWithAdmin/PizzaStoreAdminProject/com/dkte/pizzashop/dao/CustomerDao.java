package com.dkte.pizzashop.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.dkte.pizzashop.entities.Customer;
import com.dkte.pizzashop.util.DBUtil;

public class CustomerDao implements AutoCloseable {

	private Connection connection;

	public CustomerDao() throws SQLException {
		connection = DBUtil.getConnection();
	}

	public void insertCustomer(Customer customer) throws SQLException {
		String sql = "INSERT INTO customer(name,email,password,mobile) VALUES(?,?,?,?)";
		try (PreparedStatement insertStatement = connection.prepareCall(sql)) {
			insertStatement.setString(1, customer.getName());
			insertStatement.setString(2, customer.getEmail());
			insertStatement.setString(3, customer.getPassword());
			insertStatement.setString(4, customer.getMobile());
			insertStatement.executeUpdate();
		}
	}

	public Customer selectCustomer(String email, String password) throws SQLException {
		String sql = "select * from customer where email= ? AND password = ?";
		try (PreparedStatement selectStatement = connection.prepareCall(sql)) {
			selectStatement.setString(1, email);
			selectStatement.setString(2, password);
			ResultSet rs = selectStatement.executeQuery();
			if (rs != null) {
				Customer cust = new Customer();
				while (rs.next()) {
					cust.setCid(rs.getInt(1));
					cust.setName(rs.getString(2));
					cust.setEmail(rs.getString(3));
					cust.setPassword(rs.getString(4));
					cust.setMobile(rs.getString(5));
					return cust;
				}

			}

		}
		return null;

	}

	@Override
	public void close() throws SQLException {
		if (connection != null)
			connection.close();
	}

}
