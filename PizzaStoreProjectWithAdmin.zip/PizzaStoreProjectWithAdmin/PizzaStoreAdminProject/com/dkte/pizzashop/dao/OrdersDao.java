package com.dkte.pizzashop.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.dkte.pizzashop.entities.Customer;
import com.dkte.pizzashop.entities.Pizza;
import com.dkte.pizzashop.util.DBUtil;

public class OrdersDao implements AutoCloseable {

	private Connection connection;

	public OrdersDao() throws SQLException {
		connection = DBUtil.getConnection();
	}

	public void insertOrder(Customer customer, int id) throws SQLException {
		String sql = "INSERT INTO orders(cid,mid)values (?,?)";
		try (PreparedStatement ordersStatement = connection.prepareCall(sql)) {
			ordersStatement.setInt(1, customer.getCid());
			ordersStatement.setInt(2, id);
			ordersStatement.executeUpdate();
		}
	}

	public List<Pizza> OrderHistory(Customer customer) throws SQLException {
		List<Pizza> orderlist = new ArrayList<Pizza>();

		String sql = "select m.* from menu m INNER JOIN orders o ON m.mid=o.mid where cid=? ";
		try (PreparedStatement orhistorySmt = connection.prepareCall(sql)) {
			orhistorySmt.setInt(1, customer.getCid());
			ResultSet rs = orhistorySmt.executeQuery();
			while (rs.next()) {
				Pizza pizza = new Pizza();
				pizza.setMid(rs.getInt(1));
				pizza.setName(rs.getString(2));
				pizza.setDescription(rs.getString(3));
				pizza.setPrice(4);
				orderlist.add(pizza);
			}

		}
		return orderlist;
	}

	@Override
	public void close() throws Exception {
		if (connection != null)
			connection.close();
	}

}
