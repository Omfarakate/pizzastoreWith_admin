package com.dkte.pizzashop.Main;

import java.sql.SQLException;
import java.util.Scanner;

import com.dkte.pizzashop.dao.CustomerDao;
import com.dkte.pizzashop.entities.Customer;

public class MainMenu {

	public static int menu(Scanner sc) {
		System.out.println("***Welcome to Pizza Shop***");
		System.out.println("0. Exit");
		System.out.println("1. Login");
		System.out.println("2.Register");

		System.out.print("Enter Your Choice - ");
		return sc.nextInt();
	}

	private static Customer loginCustomer(Scanner sc) throws SQLException {
		try (CustomerDao customerDao = new CustomerDao()) {
			System.out.print("Enter the Email address : ");
			String email = sc.next();
			System.out.print("Enter the Password: ");
			String password = sc.next();
			Customer customer = customerDao.selectCustomer(email, password);
			if (customer != null) {
				return customer;
			} else {
				return null;
			}
		}
	}

	public static void registerCustomer(Scanner sc) throws SQLException {
		Customer cust = new Customer();
		cust.acceptCustomer(sc);
		CustomerDao custdao = new CustomerDao();
		custdao.insertCustomer(cust);
		System.out.println("Registered Successfully ");
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int choice;

		while ((choice = menu(sc)) != 0) {
			switch (choice) {
			case 1:
				System.out.println("Please Enter your Credentials to login");
				Customer customer = new Customer();
				try {
					customer = loginCustomer(sc);
					if (customer != null) {
						try {
							SubMenu.subMenu(sc, customer);
						} catch (Exception e) {

							e.printStackTrace();
						}
					} else {
						System.out.println("You entered the wrong credentials !");
					}
				} catch (SQLException e1) {

					e1.printStackTrace();
				}
				break;
			case 2:
				try {
					registerCustomer(sc);
				} catch (SQLException e) {

					e.printStackTrace();
				}

				break;

			default:
				System.out.println("You entered the wrong choice!!!");
				break;
			}
		}
		System.out.println("Thank you for shopping with us :)");
	}

}
